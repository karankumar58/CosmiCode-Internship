import string

def longest_word(sentence):
    cleaned = sentence.translate(str.maketrans('', '', string.punctuation))
    words = cleaned.split()
    longest = max(words, key=len)
    return longest


user_input = input("Enter a sentence: ")
print("Longest word:", longest_word(user_input))
