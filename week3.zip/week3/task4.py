def is_palindrome(text):
    cleaned = ''.join(char.lower() for char in text if char.isalnum())
    return cleaned == cleaned[::-1]


user_input = input("Enter a string: ")
if is_palindrome(user_input):
    print("Palindrome")
else:
    print("Not a palindrome")
