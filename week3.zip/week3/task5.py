def most_frequent_word(filename):
    with open(filename, 'r') as file:
        text = file.read().lower()
        words = text.split()

    word_count = {}
    for word in words:
        word = word.strip(",.!?\"'")  
        word_count[word] = word_count.get(word, 0) + 1

    most_frequent = max(word_count, key=word_count.get)
    return most_frequent, word_count[most_frequent]


filename = 'sample.txt'
word, count = most_frequent_word(filename)
print(f"The most frequent word is '{word}' which appears {count} times.")
