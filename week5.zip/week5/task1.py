class BankAccount:
    def __init__(self, account_number, owner_name, balance=0):
        self.account_number = account_number
        self.owner_name = owner_name
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print(f"{amount} deposited. New balance: {self.balance}")

    def withdraw(self, amount):
        if amount > self.balance:
            print("Insufficient funds.")
        else:
            self.balance -= amount
            print(f"{amount} withdrawn. Remaining balance: {self.balance}")

    def transfer(self, target_account, amount):
        if amount > self.balance:
            print("Insufficient funds for transfer.")
        else:
            self.balance -= amount
            target_account.deposit(amount)
            print(f"{amount} transferred to {target_account.owner_name}")


# Example usage:
acc1 = BankAccount("123", "Alice", 1000)
acc2 = BankAccount("456", "Bob", 500)
acc1.withdraw(200)
acc1.transfer(acc2, 300)
