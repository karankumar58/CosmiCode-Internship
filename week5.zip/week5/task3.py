class Vehicle:
    def __init__(self, brand, wheels):
        self.brand = brand
        self.wheels = wheels

    def description(self):
        print(f"{self.brand} with {self.wheels} wheels.")

class Car(Vehicle):
    def __init__(self, brand):
        super().__init__(brand, 4)

    def description(self):
        print(f"Car: {self.brand}, 4 wheels.")

class Bike(Vehicle):
    def __init__(self, brand):
        super().__init__(brand, 2)

    def description(self):
        print(f"Bike: {self.brand}, 2 wheels.")


# Example:
car = Car("Toyota")
bike = Bike("Yamaha")
car.description()
bike.description()
