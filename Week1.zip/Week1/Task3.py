a = float(input("Enter number one: "))
b = float(input("Enter number two: "))
c = float(input("Enter number three: "))

largest = max(a, b, c)
smallest = min(a, b, c)

print(f"The largest number is: {largest}")
print(f"The smallest number is: {smallest}")
