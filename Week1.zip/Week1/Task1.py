print("Hello World!")
print("My name is Karan Kumar")
print("I am a 6th semester software engineering student at DHA SUFFA University and i am interested in Python and AI ML")
