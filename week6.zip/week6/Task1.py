import time


def timer_decorator(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"Execution Time: {end - start:.4f} seconds")
        return result
    return wrapper


@timer_decorator
def power_calculation(base, exponent):
    return base ** exponent


# User Input
base = int(input("Enter base number: "))
exponent = int(input("Enter exponent: "))
result = power_calculation(base, exponent)
print("Result:", result)
