import json

data = {}
data["name"] = input("Enter your name: ")
data["age"] = int(input("Enter your age: "))

filename = "user_data.json"
# Write JSON
with open(filename, "w") as file:
    json.dump(data, file, indent=4)
    print(f"Data written to {filename}")

# Read JSON
with open(filename, "r") as file:
    loaded = json.load(file)
    print("Loaded Data:", loaded)
