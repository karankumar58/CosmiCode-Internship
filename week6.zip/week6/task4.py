from collections import Counter, defaultdict

text = input("Enter a line of text: ")

# Count frequency of each word
word_list = text.split()
counter = Counter(word_list)
print("Word Frequency:", counter)

# Group words by their starting letter
grouped = defaultdict(list)
for word in word_list:
    grouped[word[0]].append(word)

print("Grouped by Starting Letter:")
for letter, words in grouped.items():
    print(f"{letter}: {words}")
