import threading
import time


def print_even(n):
    for i in range(0, n+1, 2):
        print("Even:", i)
        time.sleep(0.5)


def print_odd(n):
    for i in range(1, n+1, 2):
        print("Odd:", i)
        time.sleep(0.5)


limit = int(input("Enter limit number: "))
t1 = threading.Thread(target=print_even, args=(limit,))
t2 = threading.Thread(target=print_odd, args=(limit,))

t1.start()
t2.start()
t1.join()
t2.join()
