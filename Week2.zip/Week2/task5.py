arr_input = input("\nEnter integers separated by spaces: ")
arr = list(map(int, arr_input.split()))

def kadane_algorithm(arr):
    max_current = max_global = arr[0]
    for i in range(1, len(arr)):
        max_current = max(arr[i], max_current + arr[i])
        max_global = max(max_global, max_current)
    return max_global

print("Maximum subarray sum is:", kadane_algorithm(arr))
