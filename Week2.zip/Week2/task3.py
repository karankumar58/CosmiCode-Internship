# Get two numbers
a = int(input("\nEnter first number: "))
b = int(input("Enter second number: "))

# GCD using Euclidean Algorithm
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

# LCM using formula
def lcm(a, b):
    return abs(a*b) // gcd(a, b)

print(f"GCD of {a} and {b}: {gcd(a, b)}")
print(f"LCM of {a} and {b}: {lcm(a, b)}")
