def fibonacci_iterative(n):
    fib = [0, 1]
    while len(fib) < n:
        fib.append(fib[-1] + fib[-2])
    return fib[:n]

def fibonacci_recursive(n):
    if n <= 0:
        return []
    if n == 1:
        return [0]
    if n == 2:
        return [0, 1]
    fib = fibonacci_recursive(n-1)
    fib.append(fib[-1] + fib[-2])
    return fib

print("\nFirst 30 Fibonacci numbers (Iterative):")
print(fibonacci_iterative(30))

print("\nFirst 30 Fibonacci numbers (Recursive):")
print(fibonacci_recursive(30))
