# Get number from user
n = int(input("\nEnter a number to find its prime factors: "))

def prime_factors(n):
    i = 2
    factors = []
    while i * i <= n:
        if n % i == 0:
            factors.append(i)
            n //= i
        else:
            i += 1
    if n > 1:
        factors.append(n)
    return factors

print(f"Prime factors of {n} are: {prime_factors(n)}")
